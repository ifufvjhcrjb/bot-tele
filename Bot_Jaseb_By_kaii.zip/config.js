module.exports = {
  BOT_TOKEN: "8188837644:AAFguESo-aawL36CYLODdEbBpqnCxteVnGU",
  OWNER_IDS: ["8113738409"],
  CHANNEL_USERNAME: "@chkurokaii",
  DEVELOPER: "@ku_kaii",
  VERSION: "1.7",
  CHANNEL_URL: "https://t.me/chkurokaii",
  MENU_IMAGES: [
    "https://files.catbox.moe/v10fc3.png"
  ]
};
